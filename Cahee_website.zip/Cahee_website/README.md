link to example - https://dmytrokabluchii.github.io/my_projects/Cahee_website/index.html

The project placed in real hosting, link to example (working form to email) - http://beetroot.zzz.com.ua/Cahee_website/

Website performance is 99%, according to pagespeed.web.dev

Single page landing, responsive design, used Pixel Perfect.

Technologies used: HTML, SCSS , jQuery, PHP(mail).

One of my first project made while studying at Beetroot Academy (10-11.2021).
